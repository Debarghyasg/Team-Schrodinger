
SMART-RETAIL MODEL — SETUP GUIDE
==================================
1. pip install -r requirements.txt
2. Place best.pt in your project folder
3. python run_model.py

Model Accuracy:
  mAP@50    : 99.0%
  Precision : 100.0%
  Recall    : 98.8%

Classes detected:
  0 = product
  1 = barcode
