
from ultralytics import YOLO
import cv2, matplotlib.pyplot as plt

# Load model
model = YOLO("best.pt")

# Run on any product image
def detect(image_path):
    results = model(image_path, conf=0.25)
    img_ann = results[0].plot()
    img_rgb = cv2.cvtColor(img_ann, cv2.COLOR_BGR2RGB)
    plt.figure(figsize=(10, 6))
    plt.imshow(img_rgb)
    plt.axis("off")
    plt.title("Smart-Retail Detection")
    plt.show()
    for box in results[0].boxes:
        cls  = int(box.cls)
        conf = float(box.conf)
        name = ["product", "barcode"][cls]
        print(f"  Detected: {name}  confidence: {conf*100:.1f}%")

detect("your_product_image.jpg")
